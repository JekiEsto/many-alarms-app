package ru.bykovtsev.manyalarms

import android.Manifest
import android.app.Activity
import android.app.AlarmManager
import android.app.AlertDialog
import android.app.TimePickerDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

class MainActivity : Activity() {
    private var hour = 7
    private var minute = 0
    private var waitingForExactPermission = false
    private lateinit var timeButton: Button
    private lateinit var countInput: EditText
    private lateinit var intervalInput: EditText
    private lateinit var listContainer: LinearLayout
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildScreen()
        refreshList()
    }

    override fun onResume() {
        super.onResume()
        if (waitingForExactPermission && exactAlarmsAllowed()) {
            waitingForExactPermission = false
            createSeries()
        }
    }

    private fun buildScreen() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(22), dp(18), dp(22), dp(18))
            setBackgroundColor(Color.rgb(248, 247, 255))
        }
        val scroll = android.widget.ScrollView(this)
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(content)

        content.addView(text("Будильники+", 30, Color.rgb(35, 31, 54), true))
        content.addView(text("Создай серию сигналов, чтобы не проспать.", 15, Color.rgb(91, 87, 105)))
        timeButton = Button(this).apply { textSize = 18f; setOnClickListener { chooseTime() } }
        content.addView(timeButton, marginTop(18))
        updateTimeButton()

        content.addView(text("Количество будильников", 15, Color.DKGRAY, true), marginTop(10))
        countInput = input("15", "Например, 15")
        content.addView(countInput)
        content.addView(text("Интервал между ними, минут", 15, Color.DKGRAY, true), marginTop(8))
        intervalInput = input("3", "Например, 3")
        content.addView(intervalInput)

        val create = Button(this).apply {
            text = "Создать серию"
            textSize = 17f
            setOnClickListener { requestPermissionsAndCreate() }
        }
        content.addView(create, marginTop(12))
        val cancel = Button(this).apply {
            text = "Отменить все будильники"
            setOnClickListener { confirmCancelAll() }
        }
        content.addView(cancel, marginTop(4))

        status = text("", 14, Color.rgb(72, 68, 84))
        content.addView(status, marginTop(10))
        content.addView(text("Запланировано", 20, Color.rgb(35, 31, 54), true), marginTop(16))
        listContainer = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        content.addView(listContainer)
        content.addView(text("Сигналы срабатывают в этом приложении. Разреши точные будильники и уведомления, чтобы Android не задерживал их.", 13, Color.GRAY), marginTop(18))

        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
    }

    private fun chooseTime() {
        TimePickerDialog(this, { _, h, m ->
            hour = h
            minute = m
            updateTimeButton()
        }, hour, minute, true).show()
    }

    private fun updateTimeButton() {
        if (::timeButton.isInitialized) timeButton.text = "Начало: %02d:%02d".format(hour, minute)
    }

    private fun requestPermissionsAndCreate() {
        val count = countInput.text.toString().toIntOrNull()
        val interval = intervalInput.text.toString().toIntOrNull()
        if (count == null || count !in 1..100) return message("Количество должно быть от 1 до 100.")
        if (interval == null || interval !in 1..1440) return message("Интервал должен быть от 1 до 1440 минут.")
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), REQ_NOTIFICATIONS)
            return
        }
        if (!exactAlarmsAllowed()) {
            waitingForExactPermission = true
            val intent = Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM)
            runCatching { startActivity(intent) }.onFailure { message("Открой настройки приложения и разреши точные будильники.") }
            return
        }
        createSeries()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQ_NOTIFICATIONS) {
            if (grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED) requestPermissionsAndCreate()
            else message("Без разрешения на уведомления сигнал может не появиться на экране.")
        }
    }

    private fun exactAlarmsAllowed(): Boolean = Build.VERSION.SDK_INT < 31 || getSystemService(AlarmManager::class.java).canScheduleExactAlarms()

    private fun createSeries() {
        val count = countInput.text.toString().toIntOrNull() ?: return
        val interval = intervalInput.text.toString().toIntOrNull() ?: return
        val start = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, hour)
            set(Calendar.MINUTE, minute)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
            if (timeInMillis <= System.currentTimeMillis()) add(Calendar.DAY_OF_YEAR, 1)
        }.timeInMillis
        AlarmStore.cancelAll(this)
        val entries = (0 until count).map { index -> AlarmEntry(index + 1, start + index * interval * 60_000L) }
        AlarmStore.write(this, entries)
        entries.forEach { AlarmStore.schedule(this, it) }
        status.text = "Создано $count будильников. Первый: ${SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date(start))}."
        refreshList()
        message("Серия будильников создана.")
    }

    private fun confirmCancelAll() {
        AlertDialog.Builder(this)
            .setTitle("Отменить все будильники?")
            .setMessage("Будут удалены все сигналы, созданные этим приложением.")
            .setNegativeButton("Назад", null)
            .setPositiveButton("Отменить все") { _, _ ->
                AlarmStore.cancelAll(this)
                status.text = "Будильники отменены."
                refreshList()
            }
            .show()
    }

    private fun refreshList() {
        if (!::listContainer.isInitialized) return
        listContainer.removeAllViews()
        val entries = AlarmStore.read(this).filter { it.at > System.currentTimeMillis() }
        if (entries.isEmpty()) {
            listContainer.addView(text("Пока нет активных будильников.", 14, Color.GRAY), marginTop(6))
            return
        }
        entries.forEachIndexed { index, entry ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(12), dp(8), dp(8), dp(8))
                setBackgroundColor(Color.WHITE)
            }
            row.addView(text("${entry.displayTime()}   ·   ${index + 1}", 16, Color.rgb(45, 41, 58)), LinearLayout.LayoutParams(0, -2, 1f))
            val delete = Button(this).apply {
                text = "×"
                setOnClickListener {
                    AlarmStore.cancel(this@MainActivity, entry)
                    AlarmStore.write(this@MainActivity, AlarmStore.read(this@MainActivity).filterNot { it.id == entry.id })
                    refreshList()
                }
            }
            row.addView(delete)
            listContainer.addView(row, marginTop(4))
        }
    }

    private fun input(value: String, hintText: String) = EditText(this).apply {
        setText(value)
        hint = hintText
        inputType = android.text.InputType.TYPE_CLASS_NUMBER
        textSize = 18f
        setPadding(dp(12), dp(8), dp(12), dp(8))
    }

    private fun text(value: String, size: Int, color: Int, bold: Boolean = false) = TextView(this).apply {
        text = value
        textSize = size.toFloat()
        setTextColor(color)
        if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD)
    }

    private fun marginTop(value: Int) = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(value) }
    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()
    private fun message(value: String) = Toast.makeText(this, value, Toast.LENGTH_LONG).show()

    companion object { private const val REQ_NOTIFICATIONS = 4102 }
}
