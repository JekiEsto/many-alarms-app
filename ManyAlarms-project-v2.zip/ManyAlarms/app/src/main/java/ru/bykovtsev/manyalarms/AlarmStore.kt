package ru.bykovtsev.manyalarms

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import org.json.JSONArray
import org.json.JSONObject

data class AlarmEntry(val id: Int, val at: Long) {
    fun displayTime(): String = java.text.SimpleDateFormat("EEE, HH:mm", java.util.Locale("ru")).format(java.util.Date(at))
}

object AlarmStore {
    private const val PREFS = "many_alarms"
    private const val KEY = "entries"

    fun read(context: Context): List<AlarmEntry> {
        val raw = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY, "[]") ?: "[]"
        return runCatching {
            val array = JSONArray(raw)
            (0 until array.length()).map { i ->
                val item = array.getJSONObject(i)
                AlarmEntry(item.getInt("id"), item.getLong("at"))
            }.sortedBy { it.at }
        }.getOrDefault(emptyList())
    }

    fun write(context: Context, entries: List<AlarmEntry>) {
        val array = JSONArray()
        entries.sortedBy { it.at }.forEach { entry ->
            array.put(JSONObject().put("id", entry.id).put("at", entry.at))
        }
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY, array.toString()).apply()
    }

    fun pendingIntent(context: Context, id: Int): PendingIntent {
        val intent = Intent(context, AlarmReceiver::class.java).putExtra("alarm_id", id)
        return PendingIntent.getBroadcast(
            context,
            id,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    fun schedule(context: Context, entry: AlarmEntry) {
        val manager = context.getSystemService(AlarmManager::class.java)
        val showIntent = PendingIntent.getActivity(
            context,
            700000 + entry.id,
            Intent(context, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val alarmClock = AlarmManager.AlarmClockInfo(entry.at, showIntent)
        manager.setAlarmClock(alarmClock, pendingIntent(context, entry.id))
    }

    fun cancel(context: Context, entry: AlarmEntry) {
        context.getSystemService(AlarmManager::class.java).cancel(pendingIntent(context, entry.id))
    }

    fun cancelAll(context: Context) {
        read(context).forEach { cancel(context, it) }
        context.getSystemService(android.app.NotificationManager::class.java).cancelAll()
        write(context, emptyList())
    }

    fun reschedule(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val manager = context.getSystemService(AlarmManager::class.java)
            if (!manager.canScheduleExactAlarms()) return
        }
        read(context).filter { it.at > System.currentTimeMillis() }.forEach { schedule(context, it) }
    }
}
