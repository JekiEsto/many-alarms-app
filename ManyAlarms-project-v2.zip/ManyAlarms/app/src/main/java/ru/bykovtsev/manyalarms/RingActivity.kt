package ru.bykovtsev.manyalarms

import android.app.Activity
import android.app.NotificationManager
import android.graphics.Color
import android.media.Ringtone
import android.media.RingtoneManager
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.WindowManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class RingActivity : Activity() {
    private var ringtone: Ringtone? = null
    private var alarmId = 1

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        alarmId = intent.getIntExtra("alarm_id", 1)
        if (Build.VERSION.SDK_INT >= 27) {
            setShowWhenLocked(true)
            setTurnScreenOn(true)
        } else {
            @Suppress("DEPRECATION")
            window.addFlags(WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON or WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        }
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(36, 36, 36, 36)
            setBackgroundColor(Color.rgb(35, 31, 54))
        }
        layout.addView(TextView(this).apply {
            text = "Пора просыпаться"
            textSize = 32f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
        })
        layout.addView(TextView(this).apply {
            text = java.text.SimpleDateFormat("HH:mm", java.util.Locale.getDefault()).format(java.util.Date())
            textSize = 64f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
        })
        layout.addView(Button(this).apply {
            text = "Остановить"
            textSize = 20f
            setOnClickListener { stopAlarm() }
        }, LinearLayout.LayoutParams(-1, -2).apply { topMargin = 32 })
        setContentView(layout)
        startSound()
    }

    override fun onDestroy() {
        ringtone?.stop()
        super.onDestroy()
    }

    private fun startSound() {
        val uri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)
            ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE)
        ringtone = RingtoneManager.getRingtone(this, uri)
        if (Build.VERSION.SDK_INT >= 28) ringtone?.isLooping = true
        ringtone?.play()
    }

    private fun stopAlarm() {
        ringtone?.stop()
        getSystemService(NotificationManager::class.java).cancel(alarmId)
        finish()
    }
}
