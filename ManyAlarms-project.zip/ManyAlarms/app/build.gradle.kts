plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "ru.bykovtsev.manyalarms"
    compileSdk = 35

    defaultConfig {
        applicationId = "ru.bykovtsev.manyalarms"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }
}
