package ru.bykovtsev.manyalarms

import android.app.Activity
import android.app.AlertDialog
import android.app.TimePickerDialog
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.AlarmClock
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.UUID

class MainActivity : Activity() {
    private var hour = 7
    private var minute = 0
    private lateinit var timeButton: Button
    private lateinit var countInput: EditText
    private lateinit var intervalInput: EditText
    private lateinit var listContainer: LinearLayout
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        removeLegacyAppAlarms()
        buildScreen()
        refreshList()
    }

    private fun removeLegacyAppAlarms() {
        val saved = AlarmStore.read(this)
        val legacy = saved.filter { it.message.isEmpty() }
        legacy.forEach { AlarmStore.cancel(this, it) }
        if (legacy.isNotEmpty()) AlarmStore.write(this, saved - legacy.toSet())
    }

    private fun buildScreen() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(22), dp(18), dp(22), dp(18))
            setBackgroundColor(Color.rgb(248, 247, 255))
        }
        val scroll = android.widget.ScrollView(this)
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(content)

        content.addView(text("Будильники+", 30, Color.rgb(35, 31, 54), true))
        content.addView(text("Создай серию будильников в стандартном приложении «Часы».", 15, Color.rgb(91, 87, 105)))
        timeButton = Button(this).apply { textSize = 18f; setOnClickListener { chooseTime() } }
        content.addView(timeButton, marginTop(18))
        updateTimeButton()

        content.addView(text("Количество будильников", 15, Color.DKGRAY, true), marginTop(10))
        countInput = input("15", "Например, 15")
        content.addView(countInput)
        content.addView(text("Интервал между ними, минут", 15, Color.DKGRAY, true), marginTop(8))
        intervalInput = input("3", "Например, 3")
        content.addView(intervalInput)

        val create = Button(this).apply {
            text = "Создать серию"
            textSize = 17f
            setOnClickListener { requestPermissionsAndCreate() }
        }
        content.addView(create, marginTop(12))
        val cancel = Button(this).apply {
            text = "Отменить все будильники"
            setOnClickListener { confirmCancelAll() }
        }
        content.addView(cancel, marginTop(4))

        status = text("", 14, Color.rgb(72, 68, 84))
        content.addView(status, marginTop(10))
        content.addView(text("Запланировано", 20, Color.rgb(35, 31, 54), true), marginTop(16))
        listContainer = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        content.addView(listContainer)
        content.addView(text("Будильники появятся в системном приложении «Часы». Для каждого используется метка серии, чтобы их можно было найти и отменить.", 13, Color.GRAY), marginTop(18))

        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
    }

    private fun chooseTime() {
        TimePickerDialog(this, { _, h, m ->
            hour = h
            minute = m
            updateTimeButton()
        }, hour, minute, true).show()
    }

    private fun updateTimeButton() {
        if (::timeButton.isInitialized) timeButton.text = "Начало: %02d:%02d".format(hour, minute)
    }

    private fun requestPermissionsAndCreate() {
        val count = countInput.text.toString().toIntOrNull()
        val interval = intervalInput.text.toString().toIntOrNull()
        if (count == null || count !in 1..100) return message("Количество должно быть от 1 до 100.")
        if (interval == null || interval !in 1..1440) return message("Интервал должен быть от 1 до 1440 минут.")
        createSeries()
    }

    private fun createSeries() {
        val count = countInput.text.toString().toIntOrNull() ?: return
        val interval = intervalInput.text.toString().toIntOrNull() ?: return
        val start = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, hour)
            set(Calendar.MINUTE, minute)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
            if (timeInMillis <= System.currentTimeMillis()) add(Calendar.DAY_OF_YEAR, 1)
        }.timeInMillis
        val clockIntent = Intent(AlarmClock.ACTION_SET_ALARM)
        if (clockIntent.resolveActivity(packageManager) == null) {
            message("Не найдено приложение «Часы», которое принимает системные будильники.")
            return
        }
        AlarmStore.read(this).filter { it.message.isEmpty() }.forEach { AlarmStore.cancel(this, it) }
        val seriesCode = UUID.randomUUID().toString().take(4).uppercase(Locale.ROOT)
        val entries = (0 until count).map { index ->
            val at = start + index * interval * 60_000L
            val label = "Будильники+ $seriesCode ${index + 1}/$count"
            AlarmEntry(index + 1, at, label)
        }
        AlarmStore.write(this, AlarmStore.read(this).filter { it.message.isNotEmpty() } + entries)
        status.text = "Передаю серию из $count будильников приложению «Часы»…"
        refreshList()
        sendSeriesToClock(entries, 0)
    }

    private fun sendSeriesToClock(entries: List<AlarmEntry>, index: Int) {
        if (index >= entries.size) {
            status.text = "Передано ${entries.size} будильников приложению «Часы». Проверь их в списке системных часов."
            return
        }
        val entry = entries[index]
        val time = Calendar.getInstance().apply { timeInMillis = entry.at }
        val intent = Intent(AlarmClock.ACTION_SET_ALARM).apply {
            putExtra(AlarmClock.EXTRA_HOUR, time.get(Calendar.HOUR_OF_DAY))
            putExtra(AlarmClock.EXTRA_MINUTES, time.get(Calendar.MINUTE))
            putExtra(AlarmClock.EXTRA_MESSAGE, entry.message)
            putExtra(AlarmClock.EXTRA_SKIP_UI, true)
        }
        try {
            startActivity(intent)
            Handler(Looper.getMainLooper()).postDelayed({ sendSeriesToClock(entries, index + 1) }, 350)
        } catch (_: Exception) {
            val remaining = entries.drop(index)
            AlarmStore.write(this, AlarmStore.read(this).filterNot { it in remaining })
            status.text = "Не удалось передать будильник ${index + 1}. Остальные не отправлены."
            refreshList()
        }
    }

    private fun confirmCancelAll() {
        AlertDialog.Builder(this)
            .setTitle("Отменить все будильники?")
            .setMessage("Будут отправлены запросы на удаление будильников этой серии из приложения «Часы». Будильники будут найдены по их уникальным меткам.")
            .setNegativeButton("Назад", null)
            .setPositiveButton("Отменить все") { _, _ ->
                val entries = AlarmStore.read(this).filter { it.message.isNotEmpty() }
                if (entries.isEmpty()) {
                    status.text = "Нет сохранённых системных будильников."
                    return@setPositiveButton
                }
                dismissSeriesFromClock(entries, 0)
            }
            .show()
    }

    private fun refreshList() {
        if (!::listContainer.isInitialized) return
        listContainer.removeAllViews()
        val entries = AlarmStore.read(this).filter { it.at > System.currentTimeMillis() }
        if (entries.isEmpty()) {
            listContainer.addView(text("Пока нет активных будильников.", 14, Color.GRAY), marginTop(6))
            return
        }
        entries.forEachIndexed { index, entry ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(12), dp(8), dp(8), dp(8))
                setBackgroundColor(Color.WHITE)
            }
            row.addView(text("${entry.displayTime()}   ·   ${entry.message}", 14, Color.rgb(45, 41, 58)), LinearLayout.LayoutParams(0, -2, 1f))
            val delete = Button(this).apply {
                text = "×"
                setOnClickListener { dismissSeriesFromClock(listOf(entry), 0) }
            }
            row.addView(delete)
            listContainer.addView(row, marginTop(4))
        }
    }

    private fun input(value: String, hintText: String) = EditText(this).apply {
        setText(value)
        hint = hintText
        inputType = android.text.InputType.TYPE_CLASS_NUMBER
        textSize = 18f
        setPadding(dp(12), dp(8), dp(12), dp(8))
    }

    private fun text(value: String, size: Int, color: Int, bold: Boolean = false) = TextView(this).apply {
        text = value
        textSize = size.toFloat()
        setTextColor(color)
        if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD)
    }

    private fun marginTop(value: Int) = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(value) }
    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()
    private fun message(value: String) = Toast.makeText(this, value, Toast.LENGTH_LONG).show()

    private fun dismissSeriesFromClock(entries: List<AlarmEntry>, index: Int) {
        if (index >= entries.size) {
            AlarmStore.write(this, AlarmStore.read(this).filterNot { it in entries })
            status.text = "Запросы на отмену отправлены приложению «Часы». Проверь список системных будильников."
            refreshList()
            return
        }
        val entry = entries[index]
        val intent = Intent(AlarmClock.ACTION_DISMISS_ALARM).apply {
            putExtra(AlarmClock.EXTRA_ALARM_SEARCH_MODE, AlarmClock.ALARM_SEARCH_MODE_LABEL)
            putExtra(AlarmClock.EXTRA_MESSAGE, entry.message)
        }
        try {
            startActivity(intent)
            Handler(Looper.getMainLooper()).postDelayed({ dismissSeriesFromClock(entries, index + 1) }, 350)
        } catch (_: Exception) {
            status.text = "Приложение «Часы» не поддержало отмену. Удали будильники с меткой Будильники+ вручную."
        }
    }
}
