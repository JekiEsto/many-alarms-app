package ru.bykovtsev.manyalarms

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import org.json.JSONArray
import org.json.JSONObject

data class AlarmEntry(val id: Int, val at: Long, val message: String = "") {
    fun displayTime(): String = java.text.SimpleDateFormat("EEE, HH:mm", java.util.Locale("ru")).format(java.util.Date(at))
}

object AlarmStore {
    private const val PREFS = "many_alarms"
    private const val KEY = "entries"

    fun read(context: Context): List<AlarmEntry> {
        val raw = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY, "[]") ?: "[]"
        return runCatching {
            val array = JSONArray(raw)
            (0 until array.length()).map { i ->
                val item = array.getJSONObject(i)
                AlarmEntry(item.getInt("id"), item.getLong("at"), item.optString("message", ""))
            }.sortedBy { it.at }
        }.getOrDefault(emptyList())
    }

    fun write(context: Context, entries: List<AlarmEntry>) {
        val array = JSONArray()
        entries.sortedBy { it.at }.forEach { entry ->
            array.put(JSONObject().put("id", entry.id).put("at", entry.at).put("message", entry.message))
        }
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY, array.toString()).apply()
    }

    fun pendingIntent(context: Context, id: Int): PendingIntent {
        val intent = Intent(context, AlarmReceiver::class.java).putExtra("alarm_id", id)
        return PendingIntent.getBroadcast(
            context,
            id,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
    }

    fun cancel(context: Context, entry: AlarmEntry) {
        context.getSystemService(AlarmManager::class.java).cancel(pendingIntent(context, entry.id))
    }
}
